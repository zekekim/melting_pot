import EventForm from "@/components/createevent";

export default async function Home() {
    return (
        <div className="flex flex-col col-span-3 ">
            < EventForm />
        </div>
    )

}
