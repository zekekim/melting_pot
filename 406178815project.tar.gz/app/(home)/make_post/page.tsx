import RecipeForm from "@/components/createpost";

export default async function Home() {
    return (

        <div className="flex flex-col col-span-3 ">
            < RecipeForm />
        </div>
    )

}
